export const API_KEY = 'YOUR_KEY_HERE'
