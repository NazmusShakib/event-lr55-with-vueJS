<template>
  <div>
    <div class="row">
      <div class="col-lg-6 col-md-12">
        <div>

        </div>
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Collapsible Accordion</h4>
            <p class="category">Bootstrap default style</p>
          </div>
          <div class="card-content">
            <el-collapse>
              <el-collapse-item title="Default Collapsible Item 1" name="1">
                <div>
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </el-collapse-item>
              <el-collapse-item title="Default Collapsible Item 1" name="2">
                <div>
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </el-collapse-item>
              <el-collapse-item title="Default Collapsible Item 1" name="3">
                <div>
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </el-collapse-item>
            </el-collapse>
          </div>
        </div>
      </div>


      <div class="col-lg-6 col-md-12">
        <div class="card card-plain">
          <div class="card-header">
            <h4 class="card-title">Collapsible Accordion on Plain Card</h4>
            <p class="category">Bootstrap default style</p>
          </div>
          <div class="card-content">
            <el-collapse>
              <el-collapse-item title="Default Collapsible Item 1" name="1">
                <div>
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </el-collapse-item>
              <el-collapse-item title="Default Collapsible Item 1" name="2">
                <div>
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </el-collapse-item>
              <el-collapse-item title="Default Collapsible Item 1" name="3">
                <div>
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
              </el-collapse-item>
            </el-collapse>

          </div>
        </div>
      </div>

    </div>

    <div class="row">
      <div class="col-lg-6 col-md-12">

        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Tabs</h4>
            <p class="category">Vertical tabs</p>
          </div>
          <div class="card-content">
            <vue-tabs class="row" direction="vertical" value="Description">
              <v-tab title="Info"><p>
                Larger, yet dramatically thinner. More powerful, but remarkably power efficient. With a smooth metal surface that seamlessly meets the new Retina HD display.</p>

                <p>
                  It’s one continuous form where hardware and software function in perfect unison, creating a new generation of phone that’s better by any measure.</p>
              </v-tab>
              <v-tab title="Description">
                <p>
                  The first thing you notice when you hold the phone is how great it feels in your hand. The cover glass curves down around the sides to meet the anodized aluminum enclosure in a remarkable, simplified design.</p>
                <p>
                  There are no distinct edges. No gaps. Just a smooth, seamless bond of metal and glass that feels like one continuous surface.</p>
              </v-tab>
              <v-tab title="Messages">
                <p>
                  It’s one continuous form where hardware and software function in perfect unison, creating a new generation of phone that’s better by any measure.</p>
                <p>
                  Larger, yet dramatically thinner. More powerful, but remarkably power efficient. With a smooth metal surface that seamlessly meets the new Retina HD display.</p>
              </v-tab>
              <v-tab title="Support">
                <p>
                  From the seamless transition of glass and metal to the streamlined profile, every detail was carefully considered to enhance your experience. So while its display is larger, the phone feels just right.</p>
                It’s one continuous form where hardware and software function in perfect unison, creating a new generation of phone that’s better by any measure.
              </v-tab>
              <v-tab title="Extra">
                Larger, yet dramatically thinner. More powerful, but remarkably power efficient. With a smooth metal surface that seamlessly meets the new Retina HD display.
                It’s one continuous form where hardware and software function in perfect unison, creating a new generation of phone that’s better by any measure.
              </v-tab>
            </vue-tabs>
          </div>
        </div>
        
      </div>
      <div class="col-lg-6 col-md-12">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">Tabs</h4>
            <p class="category">Plain text tabs</p>
          </div>
          <vue-tabs class="card-content">
            <v-tab title="Home">
              Larger, yet dramatically thinner. More powerful, but remarkably power efficient. With a smooth metal surface that seamlessly meets the new Retina HD display.
            </v-tab>
            <v-tab title="Profile">Here is your profile.</v-tab>
            <v-tab title="Messages">Here are your messages.</v-tab>
          </vue-tabs>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import Vue from 'vue'
  import {Collapse, CollapseItem} from 'element-ui'
  import VueTabs from 'vue-nav-tabs'

  Vue.use(VueTabs)
  Vue.use(Collapse)
  Vue.use(CollapseItem)
  export default {
    data () {
      return {
        activeName: 'first'
      }
    }
  }
</script>
<style>
</style>
